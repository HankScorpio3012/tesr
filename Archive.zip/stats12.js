document.addEventListener("DOMContentLoaded", function () {
  const statsList = document.getElementById("stats-list");

  // Verlinke die Hauptseite und die JavaScript-Datei
  const script1 = document.createElement("script");
  script1.src = "index12.html";
  document.head.appendChild(script1);

  const script2 = document.createElement("script");
  script2.src = "app12.js";
  document.head.appendChild(script2);

  // Stelle sicher, dass window.stats als leeres Array initialisiert wird
  if (!Array.isArray(window.stats)) {
    window.stats = [];
  }

  // Durchlaufe die Statistik und füge sie zur Statistikseite hinzu
  for (const stat of window.stats) {
    const listItem = document.createElement("li");
    listItem.textContent = `Frage: ${stat.question}, Beantwortet: ${stat.timestamp}, ${
      stat.answeredCorrectly ? "Richtig" : "Falsch"
    }`;
    statsList.appendChild(listItem);
  }
});
