// app12.js (JavaScript-Datei)
const questions = [
  {
    question: "Was ist die Hauptstadt von Frankreich?",
    options: ["Berlin", "Madrid", "Paris", "Rom"],
    answer: "Paris",
  },
  {
    question: "Welches ist das größte Tier der Welt?",
    options: ["Giraffe", "Elefant", "Walhai", "Nashorn"],
    answer: "Walhai",
  },
  // Weitere Fragen hier hinzufügen
];

const stats = window.stats || []; // Die leere Statistik-Array

let currentQuestionIndex = 0;

const questionElement = document.getElementById("question");
const answerElements = document.getElementsByName("answer");
const answerLabels = [
  document.getElementById("label1"),
  document.getElementById("label2"),
  document.getElementById("label3"),
  document.getElementById("label4"),
];
const resultElement = document.getElementById("result");

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function showNextQuestion() {
  if (currentQuestionIndex < questions.length) {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    shuffleArray(currentQuestion.options); // Mische die Antwortmöglichkeiten
    for (let i = 0; i < answerElements.length; i++) {
      answerElements[i].value = currentQuestion.options[i];
      answerLabels[i].textContent = currentQuestion.options[i];
    }
    resultElement.textContent = "";
  } else {
    currentQuestionIndex = 0; // Starte die Fragen erneut
    showNextQuestion();
  }
}

function checkAnswer() {
  const userAnswer = getSelectedAnswer();
  const correctAnswer = questions[currentQuestionIndex].answer;

  if (userAnswer === correctAnswer) {
    resultElement.textContent = "Richtig!";
  } else {
    resultElement.textContent = "Falsch. Versuche es erneut.";
  }

  // Speichere auch die Beantwortungsdaten für die Statistik
  const timestamp = new Date().toLocaleString();
  stats.push({
    question: questions[currentQuestionIndex].question,
    answeredCorrectly: userAnswer === correctAnswer,
    timestamp: timestamp,
  });

  currentQuestionIndex++;
  showNextQuestion();
}

function getSelectedAnswer() {
  for (let i = 0; i < answerElements.length; i++) {
    if (answerElements[i].checked) {
      return answerElements[i].value;
    }
  }
  return null; // Keine Antwort ausgewählt
}

showNextQuestion();

document.getElementById("submit-button").addEventListener("click", checkAnswer);
window.stats = stats; // Definiere stats als globale Variable
